package torneotenis;

public class Juvenil extends Jugador implements Practicable{
    private boolean tieneTutorDeportivo;

    public Juvenil(String nombre, int ranking, SuperficiePreferida superficiePreferida, boolean tieneTutorDeportivo) {
        super(nombre, ranking, superficiePreferida);
        this.tieneTutorDeportivo = tieneTutorDeportivo;
    }
    

    @Override
    public void practicar(){
        System.out.println("Juvenil practicando en pareja");
    }
    
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append(super.toString());
        sb.append("Tiene tutor deportivo: ").append(tieneTutorDeportivo);
        return sb.toString();
    }
    
}
