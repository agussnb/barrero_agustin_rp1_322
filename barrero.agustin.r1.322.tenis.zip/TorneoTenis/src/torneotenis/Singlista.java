package torneotenis;

public class Singlista extends Jugador implements Sacable{
    
    private int velocidadSaque;
    
    public Singlista(String nombre, int ranking, SuperficiePreferida superficiePreferida, int velocidadSaque) {
        super(nombre, ranking, superficiePreferida);
        this.velocidadSaque = velocidadSaque;
    }
    
    @Override
    public void sacar(){
        System.out.println("Soy un jugador de singles y hago mi saque a: "+velocidadSaque);
    }
    
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append(super.toString());
        sb.append("Velocidad de saque: ").append(velocidadSaque);
        return sb.toString();
    }
    
}
