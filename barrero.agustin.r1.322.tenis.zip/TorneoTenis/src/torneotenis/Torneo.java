package torneotenis;

import java.util.ArrayList;

public class Torneo {
    private String nombre;
    private ArrayList<Jugador> jugadoresInscritos = new ArrayList<>();

    public Torneo(String nombre) {
        this.nombre = nombre;
    }
    
    public void agregarJugador(Jugador jugador){
        if (jugador == null){
            throw new IllegalArgumentException("Jugador nulo");
        }
        if (this.jugadoresInscritos.contains(jugador)){
            throw new JugadorDuplicadoException("Este jugador ya esta inscripto en el torneo");
        }
        jugadoresInscritos.add(jugador);
        System.out.println("El jugador se inscribio en el torneo");
    }
    
    public String mostrarJugadores(){
        StringBuilder sb = new StringBuilder();
        sb.append("Jugadores inscritos en el torneo: ");
        sb.append("\n");
        for(Jugador j : jugadoresInscritos){

            sb.append(j);
            sb.append("\n");
        }
        return sb.toString();
    }
    
    public void sacar(){
        
        for(Jugador j : jugadoresInscritos){
            if (j instanceof Sacable s){
                s.sacar();
                
            }else if (j instanceof Doblista || j instanceof Juvenil){
                System.out.println("El jugador "+j.getNombre()+ " no puede sacar porque es "+ j.getClass().getSimpleName());
            }
        }
        
    }
    
    public void practicarEnPareja(){
        for (Jugador j : jugadoresInscritos){
            if (j instanceof Practicable p){
                p.practicar();
                
            }else if(j instanceof Singlista s){
                 System.out.println("El jugador "+j.getNombre()+ " no puede practicar en pareja porque es "+j.getClass().getSimpleName());
            }
        }
    }
    
    public void filtrarPorSuperficie(SuperficiePreferida superficie){
        int jugadoresEncontrados = 0;
        System.out.println("Jugadores que prefieren la superficie "+superficie+" :");
        for (Jugador j : jugadoresInscritos){
            if (j.getSuperficiePreferida().equals(superficie)){
                jugadoresEncontrados++;
                System.out.println(j);
                
            } 
        }
        if(jugadoresEncontrados == 0){
            System.out.println("No hay jugadores inscritos con preferencia de superficie "+superficie);
        }
    }
    
    public String generarResumenPorTipo(){
        StringBuilder sb = new StringBuilder();
        int cantJugadoresPolvo = 0;
        int cantJugadoresCesped = 0;
        int cantJugadoresCemento = 0;
        sb.append("Jugadores inscritos en el torneo: " + jugadoresInscritos.size());
        sb.append("\n");
        for (Jugador j : jugadoresInscritos){
            switch(j.getSuperficiePreferida()){
                case POLVO:
                     cantJugadoresPolvo++;
                     break;
                case CESPED:
                    cantJugadoresCesped++;
                    break;
                case CEMENTO:
                    cantJugadoresCemento++;
                    break;
            }
        }
        sb.append("Jugadores inscritos para jugar en polvo: "+cantJugadoresPolvo);
        sb.append("\n");
        sb.append("Jugadores inscritos para jugar en cesped: "+cantJugadoresCesped);
        sb.append("\n");
        sb.append("Jugadores inscritos para jugar en cemento: "+cantJugadoresCemento);
        sb.append("\n");
        return sb.toString();
    }
    
}
