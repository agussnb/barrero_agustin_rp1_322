package torneotenis;

public interface Sacable {
    void sacar();
}
