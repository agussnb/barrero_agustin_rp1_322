package torneotenis;


public class JugadorDuplicadoException extends RuntimeException{

    public JugadorDuplicadoException() {
    }
    
    public JugadorDuplicadoException(String message) {
        super(message);
    }
    
}
