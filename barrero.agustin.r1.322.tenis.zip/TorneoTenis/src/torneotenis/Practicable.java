package torneotenis;

public interface Practicable {
    void practicar();
}
