package torneotenis;

public enum SuperficiePreferida {
    POLVO,
    CESPED,
    CEMENTO
}
