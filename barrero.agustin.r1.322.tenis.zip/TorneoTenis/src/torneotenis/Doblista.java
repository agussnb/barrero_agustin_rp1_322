package torneotenis;

public class Doblista extends Jugador implements Sacable,Practicable{
    private final int CORDINACION_COMPANIERO_MIN = 1;
    private final int CORDINACION_COMPANIERO_MAX = 10;

    public Doblista(String nombre, int ranking, SuperficiePreferida superficiePreferida) {
        super(nombre, ranking, superficiePreferida);
    }
    
    @Override
    public void sacar(){
        System.out.println("Doblista haciendo el saque");
    }
    @Override
    public void practicar(){
        System.out.println("Doblista practicando en pareja");
    }
    
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append(super.toString());
        sb.append("Cordinacion minima con el companiero: ").append(CORDINACION_COMPANIERO_MIN);
        sb.append("\n");
        sb.append("Cordinacion maxima con el companiero: ").append(CORDINACION_COMPANIERO_MAX);
        return sb.toString();
    }
}
