package torneotenis;

import java.util.Objects;

public abstract class Jugador {
    private String nombre;
    private int ranking;
    private SuperficiePreferida superficiePreferida;

    public Jugador(String nombre, int ranking,SuperficiePreferida superficiePreferida) {
        this.nombre = nombre;
        this.ranking = ranking;
        this.superficiePreferida = superficiePreferida;
    }

    public String getNombre() {
        return nombre;
    }

    public SuperficiePreferida getSuperficiePreferida() {
        return superficiePreferida;
    }
    
    

    @Override
    public int hashCode() {
        return Objects.hash(nombre,ranking);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Jugador other = (Jugador) obj;
        if (this.ranking != other.ranking) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Jugador:");
        sb.append("\n");
        sb.append("Nombre: ").append(nombre);
        sb.append("\n");
        sb.append("Ranking: ").append(ranking);
        sb.append("\n");
        sb.append("Superficie preferida: ").append(superficiePreferida);
        sb.append("\n");
        return sb.toString();
    }
    
    
    
    
}
