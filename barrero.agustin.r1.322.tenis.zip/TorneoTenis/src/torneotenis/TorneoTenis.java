package torneotenis;

public class TorneoTenis {

   
    public static void main(String[] args) {
        System.out.println("Torneo de tenis Roland Garros");
        Torneo rolandGarros = new Torneo("Roland Garros");
        inscribirJugadores(rolandGarros);
        
        
        System.out.println(rolandGarros.mostrarJugadores());
        System.out.println("-------------------------------");
        rolandGarros.practicarEnPareja();
        System.out.println("-------------------------------");
        rolandGarros.sacar();
        System.out.println("-------------------------------");
        rolandGarros.filtrarPorSuperficie(SuperficiePreferida.CEMENTO);
        System.out.println("-------------------------------");
        System.out.println(rolandGarros.generarResumenPorTipo());
    }
    
    public static void inscribirJugadores(Torneo t){
        Singlista j1 = new Singlista("Agustin", 500, SuperficiePreferida.POLVO, 120);
        Singlista j2 = new Singlista("Pepe", 520, SuperficiePreferida.POLVO, 100);
        Juvenil j3 = new Juvenil("Matias", 1000, SuperficiePreferida.CESPED, true);
        Doblista j4 = new Doblista("Ricardo", 20, SuperficiePreferida.CEMENTO);
        Singlista j5 = new Singlista("Agustin", 500, SuperficiePreferida.POLVO, 120);
        
        try {
            t.agregarJugador(j1);
            t.agregarJugador(j2);
            t.agregarJugador(j3);
            t.agregarJugador(j4);
            t.agregarJugador(j5);
        } catch (JugadorDuplicadoException e) {
            System.out.println(e.getMessage());
        } catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    
}
