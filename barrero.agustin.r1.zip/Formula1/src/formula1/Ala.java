package formula1;

public class Ala extends Pieza implements Ajustador{
    
    private final int CARGA_AERO_MAX = 1;
    private final int CARGA_AERO_MIN = 10;

    public Ala(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append(super.toString());
        sb.append("Carga aerodinamica maxima: ").append(CARGA_AERO_MAX);
        
        sb.append("Carga aerodinamica minima: ").append(CARGA_AERO_MIN);
       
        return sb.toString();
    }
    
    @Override
    public void ajustar(){
        System.out.println("Ajustando el aleron...");
    }
}
