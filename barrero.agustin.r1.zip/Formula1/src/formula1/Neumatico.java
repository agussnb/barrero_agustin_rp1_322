package formula1;

public class Neumatico extends Pieza{
    
    private Compuesto compuesto;

    public Neumatico(Compuesto compuesto, String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
        this.compuesto = compuesto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Compuesto: ").append(compuesto);
      
        return sb.toString();
    }
    
    
    
}
