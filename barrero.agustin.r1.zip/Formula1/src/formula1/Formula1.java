package formula1;

public class Formula1 {

  
    public static void main(String[] args) {
        System.out.println("Sistema Formula 1");
        
        Box box = new Box("Mercedes");
        System.out.println("Estas en el box de "+box.getNombreEscuderia());
        System.out.println("\n");
        
        cargarPiezas(box);
        box.ajustarPiezas();
        System.out.println("------------------------------------------------");
        box.buscarPiezasPorCondicion(CondicionClimatica.SECO);
        System.out.println("------------------------------------------------");
        System.out.println(box.mostrarPiezas());
        
    }
     public static void cargarPiezas(Box box) {
        Motor m1 = new Motor("PU-016", "Estacion Motor", 80, CondicionClimatica.LLUVIA, 1000);
        Motor m2 = new Motor("PU-016", "Estacion Motor", 80, CondicionClimatica.LLUVIA, 1000);
        Neumatico n1 = new Neumatico(Compuesto.SOFT, "Blando", "Estacion blandos", 80, CondicionClimatica.SECO);
        Neumatico n2 = new Neumatico(Compuesto.MEDIUM, "Medio", "Estacion medios", 80, CondicionClimatica.SECO);
        Neumatico n3 = new Neumatico(Compuesto.HARD, "Duro", "Estacion duros", 90, CondicionClimatica.SECO);
        Neumatico n4 = new Neumatico(Compuesto.INTERMEDIO, "Intermedio", "Estacion intermedios", 70, CondicionClimatica.LLUVIA);
        Neumatico n5 = new Neumatico(Compuesto.WET, "Wet", "Estacion full wets", 70, CondicionClimatica.LLUVIA);
        Ala a1 = new Ala("Aleron delantero", "Estacion alerones", 60, CondicionClimatica.LLUVIA);

        try {
            box.agregarPieza(m1);
            box.agregarPieza(n1);
            box.agregarPieza(n2);
            box.agregarPieza(n3);
            box.agregarPieza(n4);
            box.agregarPieza(n5);
            box.agregarPieza(a1);
            box.agregarPieza(m2);
        } catch (PiezaDuplicadaEnBoxException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
