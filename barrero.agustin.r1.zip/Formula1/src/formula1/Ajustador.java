package formula1;

public interface Ajustador {
    void ajustar();
}
