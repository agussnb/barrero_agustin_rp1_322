package formula1;

import java.util.Objects;

public abstract class Pieza {
    private String nombre;
    private String ubicacionBox;
    private double temperaturaIdeal;
    private CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacionBox = ubicacionBox;
        this.temperaturaIdeal = temperaturaIdeal;
        this.condicionClimatica = condicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacionBox() {
        return ubicacionBox;
    }
    
    public double getTemperaturaIdeal() {
        return temperaturaIdeal;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.nombre,this.ubicacionBox);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pieza other = (Pieza) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return Objects.equals(this.ubicacionBox, other.ubicacionBox);
    }
   
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre de la pieza: "+ nombre+"\n");
        sb.append("Ubicacion en el box: "+ ubicacionBox+"\n");
        sb.append("Temperatura ideal de la pieza: "+temperaturaIdeal+"\n");
        sb.append("Condicion climatica ideal para la pieza: "+condicionClimatica+"\n");
        return sb.toString();
    }
    
    
}
