package formula1;

public enum Compuesto {
    SOFT,
    MEDIUM,
    HARD,
    INTERMEDIO,
    WET
}
