package formula1;

import java.util.ArrayList;

public class Box {
    private String nombreEscuderia;
    private ArrayList<Pieza> piezas = new ArrayList<>();

    public Box(String nombreEscuderia) {
        this.nombreEscuderia = nombreEscuderia;
        
    }

    public String getNombreEscuderia() {
        return nombreEscuderia;
    }
    
    
    public void agregarPieza(Pieza pieza){
        if (pieza == null){
            throw new IllegalArgumentException("Pieza nula");
        }
        if (this.piezas.contains(pieza)){
            throw new PiezaDuplicadaEnBoxException("Ya hay una pieza igual en el box");
        }
        piezas.add(pieza);
        System.out.println("Pieza agregada al box");
        
    }
    
    public String mostrarPiezas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Piezas en el box: \n");
        sb.append("\n");
        sb.append("Cantidad de piezas: "+ this.piezas.size());
        sb.append("\n");
        for (Pieza p : piezas){
            sb.append("\n");
            sb.append(p);
            sb.append("\n");
        }
        return sb.toString();
    }
    
    public void ajustarPiezas(){
        for (Pieza p : piezas){
           if(p instanceof Ajustador a){
               a.ajustar();
           }else{
               System.out.println(p.getNombre() + " no se puede ajustar");
           }
        }
    }
    
    public void buscarPiezasPorCondicion(CondicionClimatica condicion){
        System.out.println("Piezas pensadas para la condicion climatica: "+condicion);
        int piezasEncontradas = 0;
        for(Pieza p : this.piezas){
            if(p.getCondicionClimatica().equals(condicion)){
               
                System.out.println(p+"\n");
                piezasEncontradas ++;
            }
        }
        if(piezasEncontradas == 0){
            System.out.println("No hay piezas para la condicion: "+condicion);
        }
        
    }
    
}
