package formula1;

public class Motor extends Pieza implements Ajustador{
    
    private int potenciaMaxima;

    public Motor(String nombre, String ubicacionBox, double temperaturaIdeal, CondicionClimatica condicionClimatica, int potenciaMaxima) {
        super(nombre, ubicacionBox, temperaturaIdeal, condicionClimatica);
        this.potenciaMaxima = potenciaMaxima;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Potencia maxima:").append(potenciaMaxima);
        
        return sb.toString();
    }
    
    
    
    @Override
    public void ajustar(){
        System.out.println("Ajustando el motor...");
    }
    
    
}
